import React from "react";
import { InfoSection } from "./sections/InfoSection";
import { MainContentSection } from "./sections/MainContentSection";
import { NavigationBarSection } from "./sections/NavigationBarSection";

export const AboutUs = (): JSX.Element => {
  return (
    <div className="relative w-full bg-white overflow-hidden">
      <img
        className="absolute top-[2893px] left-[-445px] w-[1512px] h-[416px] pointer-events-none"
        alt="Vector"
        src="/figmaAssets/vector-21-1.svg"
      />

      <img
        className="absolute top-[2518px] left-[-428px] w-[1512px] h-[416px] pointer-events-none"
        alt="Vector"
        src="/figmaAssets/vector-20.svg"
      />

      <img
        className="absolute top-[1809px] left-[265px] w-[1512px] h-[416px] pointer-events-none"
        alt="Vector"
        src="/figmaAssets/vector-20-1.svg"
      />

      <NavigationBarSection />
      <MainContentSection />
      <InfoSection />
    </div>
  );
};
